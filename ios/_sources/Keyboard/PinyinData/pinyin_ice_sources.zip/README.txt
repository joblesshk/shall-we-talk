Rime Ice dictionary corresponding source for Shall We Talk build 232

Dictionary data and this generation script: GPL-3.0-only.
The application's unrelated source code is not included in this dictionary source package.

Reproduce (Python 3 standard library):
  python3 ios/tools/build_rime_ice.py --cache upstream --output ios/_sources/Keyboard/PinyinData/pinyin_ice.sqlite

Pinned upstream revision: 859e3b5300e0ea01334a627b15db101e94312a75
All upstream input hashes, legacy overlay hash and output hashes are in pinyin_ice.json.
Upstream headers and licenses are preserved. The supplied .commit marker files allow an offline build.
The legacy word list's original attribution is in THIRD_PARTY_LEXICONS.md.
SQLite versions may affect byte-level output layout; validate semantic contents as well as hashes.
